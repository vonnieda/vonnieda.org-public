ATTray 1.2
A system tray tool for controlling the AudioTron
By Jason von Nieda <jason@vonnieda.org>

1. What it does
	ATTray allows you to control the basic functions of your AudioTron
from the Windows system tray. It installs a small icon which looks like the
play button on your AudioTron which you can right click for options. You can
also double click to skip to the next song.

2. What it requires
	ATTray requires that you have a AudioTron connected to your network
and that it is accessible from your computer.
	ATTray also requires that you have firmware version 2.1.13 or higher.
ATTray uses the new AudioTron API to control your AudioTron and 2.1.13 is
the first version of the firmware to support it. For more information on
firmware, check here: http://pub90.ezboard.com/fturtlebeachfrm10

3. How to install
	You should have received a .zip file containing ATTray.exe and this
README file. Simply put the ATTray.exe in a place that is convienent for you
such as C:\Windows and create a shortcut to it. I also have a shortcut in my
Startup folder so that ATTRay starts every time my computer does.

4. License
	Do whatever you want with it except say you wrote it. If you would
like the source code, drop me a line and I will give it to you. The source
will also be available on the web site eventually.

5. Warranty
	I take no responsibility for anything this program might do to you,
your computer, your dog or your mental stability. There is no warranty.
With that in mind, it probally won't do anything bad.

6. Notes
	This is the first Win32 program I have written and shown to anyone.
I am beginning Win32 programmer so it's very possible this program violates
all Win32 programming guidelines. I'll do better next time. Promise.

7. Changes

03/03/2002 v1.0
	* Initial version

03/03/2002 v1.1
	* Added authentication.
	* Started working on interpreting returns from the AT. This will
	  let us tell the user when they have a invalid password and such.

03/11/2002 v1.2
	* Added DNS support
	* Added Web Console menu option. Opens a browser window to the AT.
	* First version using new networking code. Probally slower, buggier
	  and in general, worse... but it is getting better :)
	* Added simple status during network activity. The icon goes gray while the
	  program communicates with the AT.
	* Added single left click pause / unpause.
	* Fix a bug in my registry code. Cause some builds to not be able to load
	  configuration information. Initialize those variables!

03/17/2002 v1.3
	* Added basic polling! The icon in the tray should now represent the
	  current state of the AT. Currently shows Stopped, Playing and Paused.
	  The menu also shows the state of all the buttons on the front of the
	  AT using checkmarks. The current polling interval is 3 seconds.
	* Switching to wininet for all networking code. Much easier and more useful
	  than writing it all myself.
	* Now shows a message when the program can communicate with the AT but you
	  have specified the wrong password.
	* Added a homepage button to the about box that will open a browser to the home
	  page.
	* Added new version notification. Simply checks the web site for a new version
	  and pops up a box to let you know.


8. Todo

	* Add a little help box.

9. Bugs
	* I don't know how to make the program not try to load my icons as 32x32 and
	  scale them down. I have 16x16 icons, but they are getting scalled up and
	  then down, which makes the Stop icon look broken.







